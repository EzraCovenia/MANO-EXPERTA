
import React, { useState, useEffect, useRef } from 'react';
import { MOCK_PROS, CATEGORIES, I18N, COUNTRIES } from './constants';
import { Professional, Category, Subscription, LocationData, BankAccount, UserRole, CountryCode } from './types';
import { reverseGeocode } from './services/geminiService';
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

const App: React.FC = () => {
  const [lang, setLang] = useState('es');
  const [currentCountry, setCurrentCountry] = useState(COUNTRIES[0]);
  const [currentRole, setCurrentRole] = useState<UserRole>('cliente');
  const [activeCategory, setActiveCategory] = useState<Category | 'Todos'>('Todos');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPro, setSelectedPro] = useState<Professional | null>(null);
  const [showLogin, setShowLogin] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userLocation, setUserLocation] = useState<LocationData | null>(null);
  const [allPros, setAllPros] = useState<Professional[]>(MOCK_PROS);
  const [showInstallBanner, setShowInstallBanner] = useState(false);
  
  // Estado para el formulario de nuevo maestro
  const [newPro, setNewPro] = useState({
    name: '',
    category: 'Plomería' as Category,
    hourlyRate: '',
    description: ''
  });

  const t = (key: string) => I18N[lang]?.[key] || key;

  useEffect(() => {
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      setShowInstallBanner(true);
    });

    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(async (pos) => {
        try {
          const info = await reverseGeocode(pos.coords.latitude, pos.coords.longitude);
          setUserLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude, ...info });
          const countryMatch = COUNTRIES.find(c => c.name.toLowerCase() === info.country?.toLowerCase());
          if (countryMatch) setCurrentCountry(countryMatch);
        } catch (e) { console.error("Error geolocating", e); }
      });
    }
  }, []);

  const handleRegisterPro = (e: React.FormEvent) => {
    e.preventDefault();
    const pro: Professional = {
      id: Math.random().toString(36).substr(2, 9),
      name: newPro.name,
      category: newPro.category,
      rating: 5.0,
      reviewsCount: 0,
      hourlyRate: parseInt(newPro.hourlyRate),
      currency: currentCountry.currency,
      description: newPro.description,
      imageUrl: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400', // Foto genérica
      location: userLocation || { lat: 0, lng: 0, country: currentCountry.name, countryCode: currentCountry.code, commune: 'Mi Ciudad' },
      verified: false,
      skills: [newPro.category],
      yearsExperience: 1,
    };
    setAllPros([pro, ...allPros]);
    setNewPro({ name: '', category: 'Plomería', hourlyRate: '', description: '' });
    alert("¡Felicidades! Ahora eres un Maestro en Mano Experta.");
    setCurrentRole('cliente');
  };

  const formatPrice = (price: number, currency: string) => {
    return new Intl.NumberFormat(lang, { style: 'currency', currency, maximumFractionDigits: 0 }).format(price);
  };

  const filteredPros = allPros.filter(pro => {
    const matchesCountry = pro.location.countryCode === currentCountry.code;
    const matchesCategory = activeCategory === 'Todos' || pro.category === activeCategory;
    const matchesSearch = pro.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         pro.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCountry && matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen pb-24 md:pb-12 bg-white selection:bg-indigo-100">
      {/* NAVBAR */}
      <nav className="sticky top-0 z-50 glass border-b border-slate-200 py-3 px-6 flex justify-between items-center pt-safe">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <div className="bg-indigo-600 text-white p-2 rounded-xl font-black text-xl shadow-lg">ME</div>
            <h1 className="text-xl font-black text-slate-900 tracking-tighter hidden sm:block">MANO EXPERTA</h1>
          </div>
          <div className="flex items-center gap-2 bg-slate-100 px-3 py-2 rounded-xl">
            <span className="text-lg">{currentCountry.flag}</span>
            <span className="text-xs font-black text-slate-700 uppercase">{currentCountry.code}</span>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <button onClick={() => setCurrentRole(currentRole === 'cliente' ? 'profesional' : 'cliente')} className="text-xs font-black text-indigo-600 hover:text-indigo-700 underline underline-offset-4">
            {currentRole === 'cliente' ? '¿Eres Maestro?' : 'Vista Cliente'}
          </button>
          <div className="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center border-2 border-white shadow-sm overflow-hidden">
             <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Felix" alt="avatar" />
          </div>
        </div>
      </nav>

      {currentRole === 'cliente' ? (
        <>
          <header className="px-6 pt-24 pb-28 text-center bg-slate-50 relative overflow-hidden">
            <div className="max-w-4xl mx-auto relative z-10">
              <h2 className="text-5xl md:text-7xl font-black text-slate-900 mb-6 leading-tight tracking-tight">
                {t('heroTitle')} <span className="text-indigo-600">{currentCountry.name}</span>
              </h2>
              <div className="bg-white p-2 rounded-3xl shadow-2xl border border-slate-200 flex flex-col md:flex-row gap-2 max-w-3xl mx-auto">
                <input 
                  type="text" 
                  placeholder={t('searchPlaceholder')} 
                  className="flex-1 py-5 px-6 bg-transparent outline-none text-slate-700 font-bold"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <button className="px-12 py-5 bg-indigo-600 text-white rounded-2xl font-black shadow-lg hover:bg-indigo-700 active:scale-95 transition">Buscar</button>
              </div>
            </div>
          </header>

          <main className="max-w-7xl mx-auto px-6 -mt-10 mb-20 relative z-20">
            <div className="flex overflow-x-auto gap-3 pb-8 no-scrollbar scroll-smooth">
              {['Todos', ...CATEGORIES.map(c => c.name)].map(cat => (
                <button 
                  key={cat}
                  onClick={() => setActiveCategory(cat as any)}
                  className={`px-8 py-4 rounded-2xl font-black transition-all whitespace-nowrap shadow-sm flex items-center gap-2 ${
                    activeCategory === cat ? 'bg-slate-900 text-white' : 'bg-white text-slate-500 border border-slate-100'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {filteredPros.map(pro => (
                <div key={pro.id} onClick={() => setSelectedPro(pro)} className="group bg-white rounded-[2.5rem] border border-slate-100 overflow-hidden shadow-sm hover:shadow-2xl transition-all cursor-pointer">
                  <div className="h-64 relative overflow-hidden">
                    <img src={pro.imageUrl} className="h-full w-full object-cover group-hover:scale-105 transition-transform" />
                  </div>
                  <div className="p-8">
                    <h3 className="font-black text-slate-900 text-xl">{pro.name}</h3>
                    <p className="text-[10px] font-black text-indigo-600 uppercase mb-6">{pro.category}</p>
                    <div className="flex justify-between items-center pt-5 border-t border-slate-50">
                      <span className="text-xs font-black text-slate-900">{pro.location.commune || 'Cerca de ti'}</span>
                      <span className="text-lg font-black text-indigo-600">{formatPrice(pro.hourlyRate, pro.currency)}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </main>
        </>
      ) : (
        <div className="max-w-6xl mx-auto px-6 pt-16 mb-20">
           <div className="grid lg:grid-cols-2 gap-12">
              {/* FORMULARIO DE REGISTRO */}
              <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-xl">
                 <h2 className="text-3xl font-black text-slate-900 mb-2">Únete como Maestro</h2>
                 <p className="text-slate-400 mb-8 font-medium">Empieza a recibir clientes en {currentCountry.name} hoy mismo.</p>
                 
                 <form onSubmit={handleRegisterPro} className="space-y-4">
                    <div>
                       <label className="text-[10px] font-black text-slate-400 uppercase ml-2">Nombre Completo</label>
                       <input required type="text" value={newPro.name} onChange={e => setNewPro({...newPro, name: e.target.value})} className="w-full bg-slate-50 p-5 rounded-2xl outline-none border border-slate-100 focus:ring-2 focus:ring-indigo-100 transition" placeholder="Ej: Juan Pérez" />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                       <div>
                          <label className="text-[10px] font-black text-slate-400 uppercase ml-2">Especialidad</label>
                          <select value={newPro.category} onChange={e => setNewPro({...newPro, category: e.target.value as Category})} className="w-full bg-slate-50 p-5 rounded-2xl outline-none border border-slate-100">
                             {CATEGORIES.map(c => <option key={c.name} value={c.name}>{c.name}</option>)}
                          </select>
                       </div>
                       <div>
                          <label className="text-[10px] font-black text-slate-400 uppercase ml-2">Precio por Hora ({currentCountry.currency})</label>
                          <input required type="number" value={newPro.hourlyRate} onChange={e => setNewPro({...newPro, hourlyRate: e.target.value})} className="w-full bg-slate-50 p-5 rounded-2xl outline-none border border-slate-100" placeholder="Ej: 20000" />
                       </div>
                    </div>
                    <div>
                       <label className="text-[10px] font-black text-slate-400 uppercase ml-2">Breve Descripción</label>
                       <textarea required value={newPro.description} onChange={e => setNewPro({...newPro, description: e.target.value})} className="w-full bg-slate-50 p-5 rounded-2xl outline-none border border-slate-100 h-32" placeholder="Cuéntanos tu experiencia..."></textarea>
                    </div>
                    <button type="submit" className="w-full py-6 bg-indigo-600 text-white rounded-2xl font-black shadow-xl hover:bg-indigo-700 transition active:scale-95">Registrarme como Maestro</button>
                 </form>
              </div>

              {/* GUIA DE DESPLIEGUE GITHUB */}
              <div className="space-y-8">
                 <div className="bg-indigo-900 p-10 rounded-[3rem] text-white">
                    <h3 className="text-2xl font-black mb-6 flex items-center gap-3">
                       <span className="text-3xl">🚀</span> Guía de Publicación (GitHub)
                    </h3>
                    <div className="space-y-6">
                       <div className="flex gap-4">
                          <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center font-black shrink-0">1</div>
                          <div>
                             <p className="font-black text-sm uppercase tracking-widest text-indigo-300">Sube tu Código</p>
                             <p className="text-xs opacity-80 leading-relaxed">Crea un repositorio en GitHub llamado "mano-experta" y sube estos archivos.</p>
                          </div>
                       </div>
                       <div className="flex gap-4">
                          <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center font-black shrink-0">2</div>
                          <div>
                             <p className="font-black text-sm uppercase tracking-widest text-indigo-300">Conecta a Vercel</p>
                             <p className="text-xs opacity-80 leading-relaxed">Entra a <b>vercel.com</b>, dale a "Add New" -> "Project" y selecciona tu repositorio de GitHub.</p>
                          </div>
                       </div>
                       <div className="flex gap-4">
                          <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center font-black shrink-0">3</div>
                          <div>
                             <p className="font-black text-sm uppercase tracking-widest text-indigo-300">¡Listo!</p>
                             <p className="text-xs opacity-80 leading-relaxed">Vercel te dará un link (ej: mano-experta.vercel.app) que cualquiera en el mundo podrá abrir.</p>
                          </div>
                       </div>
                    </div>
                    <a href="https://vercel.com/new" target="_blank" className="mt-8 block w-full py-4 bg-white text-indigo-900 text-center rounded-xl font-black hover:bg-indigo-50 transition">Ir a Vercel ahora</a>
                 </div>

                 <div className="bg-slate-900 p-10 rounded-[3rem] text-white">
                    <h3 className="text-xl font-black mb-4">Próximo Paso: Base de Datos</h3>
                    <p className="text-xs opacity-60 leading-relaxed mb-6">
                       Ahora los maestros se guardan solo en tu navegador. Para que todos vean a todos los maestros, necesitas conectar <b>Supabase</b> o <b>Firebase</b>. Es gratis para empezar y te permite tener miles de usuarios.
                    </p>
                    <div className="flex items-center gap-2">
                       <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                       <span className="text-[10px] font-black uppercase tracking-widest text-emerald-500">Sugerencia: Usa Supabase</span>
                    </div>
                 </div>
              </div>
           </div>
        </div>
      )}

      {/* DETALLES DEL MAESTRO */}
      {selectedPro && (
        <div className="fixed inset-0 z-[110] flex items-end md:items-center justify-center p-0 md:p-4">
          <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-sm" onClick={() => setSelectedPro(null)}></div>
          <div className="bg-white rounded-t-[3rem] md:rounded-[4rem] w-full max-w-2xl relative z-10 p-10 md:p-14 shadow-2xl animate-in slide-in-from-bottom-20 duration-500">
             <div className="flex justify-between items-start mb-8">
                <div className="flex items-center gap-5">
                   <img src={selectedPro.imageUrl} className="w-20 h-20 rounded-3xl object-cover shadow-xl" />
                   <div>
                      <h2 className="text-4xl font-black text-slate-900 leading-tight">{selectedPro.name}</h2>
                      <span className="text-indigo-600 font-black uppercase text-[10px] tracking-widest bg-indigo-50 px-3 py-1 rounded-full">{selectedPro.category}</span>
                   </div>
                </div>
                <button onClick={() => setSelectedPro(null)} className="w-12 h-12 flex items-center justify-center bg-slate-100 rounded-full text-slate-400">✕</button>
             </div>
             <p className="text-slate-500 font-medium mb-10 leading-relaxed text-lg">{selectedPro.description}</p>
             <div className="flex justify-between items-center bg-slate-50 p-8 rounded-3xl border border-slate-100 mb-10">
                <span className="text-sm font-black text-slate-400 uppercase">Tarifa</span>
                <span className="text-3xl font-black text-indigo-600">{formatPrice(selectedPro.hourlyRate, selectedPro.currency)}/hr</span>
             </div>
             <button onClick={() => { setSelectedPro(null); alert("¡Iniciando conversación!"); }} className="w-full py-6 bg-indigo-600 text-white font-black rounded-[2rem] shadow-2xl hover:bg-indigo-700 transition active:scale-95 text-lg">
                Contactar Maestro
             </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
