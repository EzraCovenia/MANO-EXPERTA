
export type Category = 'Plomería' | 'Electricidad' | 'Carpintería' | 'Jardinería' | 'Pintura' | 'Construcción' | 'Limpieza';

export type UserRole = 'cliente' | 'profesional';

export type CountryCode = 'CL' | 'MX' | 'CO' | 'ES' | 'AR';

export interface LocationData {
  lat: number;
  lng: number;
  address?: string;
  commune?: string;
  region?: string;
  country: string;
  countryCode?: CountryCode;
}

export interface BankAccount {
  bankName: string;
  accountNumber: string;
  accountType: string;
  holderName: string;
  idNumber: string; // RUT o DNI
  email?: string;
}

export interface Subscription {
  active: boolean;
  tier: 'premium' | 'standard';
  country: string;
  expiresAt?: string;
}

export interface Professional {
  id: string;
  name: string;
  category: Category;
  rating: number;
  reviewsCount: number;
  hourlyRate: number;
  currency: string;
  description: string;
  imageUrl: string;
  location: LocationData;
  verified: boolean;
  skills: string[];
  bankAccount?: BankAccount;
  yearsExperience?: number;
  gallery?: string[];
  isTopRated?: boolean;
}

export interface Translations {
  [key: string]: {
    [key: string]: string;
  };
}
