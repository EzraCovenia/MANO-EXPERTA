
import { GoogleGenAI, Type } from "@google/genai";
import { LocationData } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getSmartRecommendations = async (userDescription: string, userLocation?: LocationData) => {
  try {
    const locationContext = userLocation 
      ? `El usuario está en ${userLocation.commune}, ${userLocation.region}, ${userLocation.country}.`
      : 'Ubicación desconocida.';

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Actúa como un asistente local de servicios. 
      Contexto de Ubicación: ${locationContext}
      Necesidad del cliente: "${userDescription}"
      
      Analiza si la necesidad requiere un profesional específico y si hay factores geográficos relevantes. 
      Responde en JSON.`,
      config: {
        tools: [{ googleMaps: {} }],
        toolConfig: {
          retrievalConfig: {
            latLng: userLocation ? { latitude: userLocation.lat, longitude: userLocation.lng } : undefined
          }
        },
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            category: { type: Type.STRING },
            skills: { type: Type.ARRAY, items: { type: Type.STRING } },
            explanation: { type: Type.STRING },
            locationWarning: { type: Type.STRING, description: 'Aviso si el servicio es difícil de encontrar en su zona.' }
          },
          required: ["category", "skills", "explanation"]
        }
      }
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("Gemini Error:", error);
    return null;
  }
};

export const reverseGeocode = async (lat: number, lng: number) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Dadas las coordenadas ${lat}, ${lng}, identifica la Comuna (o vecindario), Ciudad y Región. Sé breve.`,
      config: {
        tools: [{ googleMaps: {} }],
        toolConfig: {
          retrievalConfig: {
            latLng: { latitude: lat, longitude: lng }
          }
        },
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            commune: { type: Type.STRING },
            city: { type: Type.STRING },
            region: { type: Type.STRING },
            country: { type: Type.STRING }
          }
        }
      }
    });
    return JSON.parse(response.text);
  } catch (error) {
    return { commune: 'Ubicación desconocida', region: '' };
  }
};
