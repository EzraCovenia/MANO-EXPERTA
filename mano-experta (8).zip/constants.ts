
import { Professional, Category, Translations, CountryCode } from './types';

export const COUNTRIES: { code: CountryCode; name: string; flag: string; currency: string }[] = [
  { code: 'CL', name: 'Chile', flag: '🇨🇱', currency: 'CLP' },
  { code: 'MX', name: 'México', flag: '🇲🇽', currency: 'MXN' },
  { code: 'CO', name: 'Colombia', flag: '🇨🇴', currency: 'COP' },
  { code: 'ES', name: 'España', flag: '🇪🇸', currency: 'EUR' },
  { code: 'AR', name: 'Argentina', flag: '🇦🇷', currency: 'ARS' },
];

export const CATEGORIES: { name: Category; icon: string }[] = [
  { name: 'Plomería', icon: '🔧' },
  { name: 'Electricidad', icon: '⚡' },
  { name: 'Carpintería', icon: '🪚' },
  { name: 'Jardinería', icon: '🌿' },
  { name: 'Pintura', icon: '🎨' },
  { name: 'Construcción', icon: '🏗️' },
  { name: 'Limpieza', icon: '🧹' },
];

export const I18N: Translations = {
  es: {
    heroTitle: 'Maestros expertos en',
    heroSubtitle: 'Deja las labores del hogar a verdaderos maestros',
    searchPlaceholder: '¿Qué necesitas reparar o limpiar hoy?',
    trustTitle: 'Garantía Mano Experta',
    trustDesc: 'Todos nuestros maestros pasan por un riguroso proceso de verificación de identidad y antecedentes.',
    becomePro: 'Quiero ofrecer mis servicios',
  }
};

export const MOCK_PROS: Professional[] = [
  {
    id: '1',
    name: 'Carlos Rodríguez',
    category: 'Plomería',
    rating: 4.8,
    reviewsCount: 124,
    hourlyRate: 25000,
    currency: 'CLP',
    description: 'Especialista en fugas complejas en edificios residenciales.',
    imageUrl: 'https://images.unsplash.com/photo-1581244277943-fe4a9c777189?w=400',
    location: { lat: -33.4263, lng: -70.6166, commune: 'Providencia', region: 'Metropolitana', country: 'Chile', countryCode: 'CL' },
    verified: true,
    skills: ['Tuberías', 'Emergencias'],
    yearsExperience: 12,
    isTopRated: true,
  },
  {
    id: '4',
    name: 'Ana Silva',
    category: 'Limpieza',
    rating: 4.9,
    reviewsCount: 210,
    hourlyRate: 15000,
    currency: 'CLP',
    description: 'Aseo profesional para hogares y oficinas. Especialista en sanitización y orden profundo.',
    imageUrl: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=400',
    location: { lat: -33.5116, lng: -70.7526, commune: 'Maipú', region: 'Metropolitana', country: 'Chile', countryCode: 'CL' },
    verified: true,
    skills: ['Aseo Hogar', 'Oficinas'],
    yearsExperience: 10,
    isTopRated: true,
  },
  {
    id: 'mx-1',
    name: 'Javier Mendoza',
    category: 'Electricidad',
    rating: 4.7,
    reviewsCount: 56,
    hourlyRate: 450,
    currency: 'MXN',
    description: 'Maestro electricista certificado. Instalaciones y reparaciones garantizadas.',
    imageUrl: 'https://images.unsplash.com/photo-1541888941255-081d746feaca?w=400',
    location: { lat: 19.4326, lng: -99.1332, commune: 'Polanco', region: 'CDMX', country: 'México', countryCode: 'MX' },
    verified: true,
    skills: ['Tableros', 'Cámaras'],
    yearsExperience: 7,
  },
  {
    id: 'es-1',
    name: 'Ignacio Ruiz',
    category: 'Carpintería',
    rating: 4.9,
    reviewsCount: 18,
    hourlyRate: 35,
    currency: 'EUR',
    description: 'Ebanista con 20 años de experiencia. Muebles a medida y restauración.',
    imageUrl: 'https://images.unsplash.com/photo-1533090161767-e6ffed986c88?w=400',
    location: { lat: 40.4168, lng: -3.7038, commune: 'Chamberí', region: 'Madrid', country: 'España', countryCode: 'ES' },
    verified: true,
    skills: ['Muebles', 'Restauración'],
    yearsExperience: 20,
    isTopRated: true,
  }
];
